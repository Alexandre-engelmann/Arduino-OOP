class led
{
  byte led_pin;
  private:
  int i;
  int ledPins[4] = {13,12,11,10}; // LED pins  outside class you are allow to put int ledPins[] = {13,12,11,10}; // LED pins
  int len_ledPins = sizeof(ledPins)/sizeof (int);  
  public:
    void pin_config(byte pin);
    void pin_on(void);
    void pin_off(void);
    int pin_inf();
    char pin_charinf();
    void pin_s_inf();
};

void led::pin_config(byte pin){
  led_pin = pin;
  pinMode(led_pin,OUTPUT);
}

void led::pin_on(void){
  digitalWrite(led_pin,HIGH);
  i=1;
}

void led::pin_off(void){
  digitalWrite(led_pin,LOW);
  i=0;
}

int led::pin_inf(){
  return i;
}

char led::pin_charinf(){
  if (i==10){
    Serial.print("inside a method is equal to 10");
  }
  else{
   Serial.print("inside a method is not equal to 10");
  }
}

void led::pin_s_inf(){
  if(i==1){
    Serial.println(String("The follow led : ") +led_pin+ String(" is on"));
}
  else if (i==0){
    Serial.println(String("The follow led : ") +led_pin+ String(" is off"));
  }
  else {
    Serial.println("Inconsistence");
  }
}
