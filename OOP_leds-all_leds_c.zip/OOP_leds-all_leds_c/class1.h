class AllLeds
{
  private:
// LED pins  outside class you are allow to put int ledPins[] = {13,12,11,10}; // LED pins

    int ledPins[4] = {13,12,11,10}; 
    int len_ledPins = sizeof(ledPins)/sizeof (int);
    int ps=10; 
  public:
    void pins_config(void);
    void all_pins_on(void);
    void all_pins_off(void);
    void print_variables(void);
    void print_all_pins_status(void);
};

void AllLeds::pins_config(void){
    for(int i = 0; i < len_ledPins; i++) 
  {
    pinMode(ledPins[i], OUTPUT);
  }
}


void AllLeds::all_pins_on(void){
 for(int i = 0; i < len_ledPins; i++) 
  {
    digitalWrite(ledPins[i], HIGH);
    ps=1;
  } 
}
void AllLeds::all_pins_off(void){
 for(int i = 0; i < len_ledPins; i++) 
  {
    digitalWrite(ledPins[i], LOW);
    ps=0;
  } 
}

void AllLeds::print_variables(void)
{
 for(int i = 0; i < len_ledPins; i++) 
  {
    Serial.println(String("Contador i = ") + i);
    Serial.println(String("ledPins = ") + ledPins[i] );
    Serial.println(String("len_ledPins = ") + len_ledPins);
  } 
}

void AllLeds::print_all_pins_status(void)
{
  if (ps==0){
  Serial.println(" All Leds status is on ");}
  else if(ps==1){
  Serial.println(" All Leds status is off ");}
  else {
  Serial.println("Inconsistence");  }
}
