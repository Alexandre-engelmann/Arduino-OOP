class blink{ //class blink
public:

void OP(byte pinNum){ //Output Pin
  pinMode(pinNum, 1); //pinMode function
}

void PH(byte pinNum){  //Pin High
  digitalWrite( pinNum, 1);
}

  void PL(byte pinNum){  //Pin Low
  digitalWrite( pinNum, 0);
}

  void PS(byte pinNum){ //Pin Switch
  digitalWrite( pinNum, !digitalRead(pinNum));
}
};

